export interface ILogin {
    id: string;
    username: string;
    password: string;
          
}